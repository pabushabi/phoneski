module.exports = {
  "transpileDependencies": [
    "vuetify"
  ],
  // publicPath: 'testingsometests'
}
